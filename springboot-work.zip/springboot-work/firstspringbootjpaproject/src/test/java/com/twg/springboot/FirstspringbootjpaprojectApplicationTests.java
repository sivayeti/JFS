package com.twg.springboot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FirstspringbootjpaprojectApplicationTests {

	@Test
	void contextLoads() {
	}

}
