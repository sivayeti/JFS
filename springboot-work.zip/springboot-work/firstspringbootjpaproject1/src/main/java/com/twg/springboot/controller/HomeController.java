package com.twg.springboot.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

import com.twg.springboot.entity.Employee;
import com.twg.springboot.service.EmployeeService;

//@RestController  //to specify spring that these is the controller which sends the request to service layer
//In normal cases we will use @RestController, but in spring boot when we use jsp technology then we have to use @Controller
@Controller
public class HomeController {
	
	@Autowired  //it makes the spring to inject its interface created object to here to the object variable ,so here object variable using these we can use the methods in its class. 
	private EmployeeService employeeService; //the user defined data type i.e class which is property here, but it is class some where, to acces its class methods, we have to create the object for that class here, then only by using that object we can access the methods in class , but if we create object here, we will face tight coupling to avoid that , we have to create the object from outside, during run time we have to inject or assign the object to here for the variable employeeService.
	
	@GetMapping("/")
	public String insertEmployee(Model model)
	
	{
		Employee employee = new Employee();
		employee.setName("Kishore");
		employee.setDesignation("Manager");
		employee.setDepartment("Accounts");
		employee.setExp(30);
		
		Employee emp = employeeService.saveEmployee(employee);
		//return "Employee "+emp.getName()+" with id "+ emp.getId()+" is saved successfully";	
		
		String msg = "Employee "+emp.getName()+" with id "+ emp.getId()+" is saved successfully";	
		
		//Actually we performed ModelAndView class and return the model object, but instead of that we can proceed with these like passing Model as object ,for that object variable we can pass the attributes or emp object.
		model.addAttribute("employee", emp);
		model.addAttribute("message",msg);
		return "home";
		//Actually we performed ModelAndView class and return the model object, but instead of that we can proceed with these like passing Model as object ,for that object variable we can pass the attributes or emp object.
	}
	
	

}
