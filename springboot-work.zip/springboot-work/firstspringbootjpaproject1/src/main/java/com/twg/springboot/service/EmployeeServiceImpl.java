package com.twg.springboot.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.twg.springboot.entity.Employee;
import com.twg.springboot.repository.EmployeeRepository;

@Service //we have to use these tag then only spring understands that these is service class
public class EmployeeServiceImpl implements EmployeeService {

	//In spring mvc service/business layer takes the help of DAO layer object, and by using that object it requests the DAO layer, and then DAO layer performs the requested operation on database
	//In spring boot DAO layer means repository layer, service layer takes the help of repository layer 
	
	@Autowired
	EmployeeRepository employeeRepository;
	
	@Override
	public Employee saveEmployee(Employee employee) {

		return employeeRepository.save(employee);
	}

	@Override
	public Employee updateEmployee(Employee employee) {
		// TODO Auto-generated method stub
		return employeeRepository.save(null);
		//Reposiory Interface which extends JPARepositry, for insert, & update operation we will  use the save() method only for both.
		//How it will works in backend means if employee object has ID field ,then it searches entire table with that  id, when it finds the row it understands that it is existed and now we have to perform update, if we not pass the employee object with id, then it will autoincrements the id, and performs insert operation on table.
	}

	@Override
	public void deleteEmployee(Employee employee) {
		// TODO Auto-generated method stub

		employeeRepository.delete(employee);
		
	}

	@Override
	public Employee findById(long id) {
		// TODO Auto-generated method stub
		return employeeRepository.findById(id).get();
	}

	@Override
	public List<Employee> findAll() {
		// TODO Auto-generated method stub
		List<Employee> employees = employeeRepository.findAll();
		return employees;
	}

}
