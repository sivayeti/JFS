package com.twg.springboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Firstspringbootproject1Application {

	public static void main(String[] args) {
		SpringApplication.run(Firstspringbootproject1Application.class, args);
	}

}
