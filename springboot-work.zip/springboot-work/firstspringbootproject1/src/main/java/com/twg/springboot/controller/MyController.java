package com.twg.springboot.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;


@RestController
public class MyController {
	
	@GetMapping("/") // "/" means by default whenever our application runs on server these method should execute
	public String sayHello()
	{
		return "Welcome to my first spring boot application";
	}
}
