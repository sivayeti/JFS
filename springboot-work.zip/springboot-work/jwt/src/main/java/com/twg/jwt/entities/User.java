package com.twg.jwt.entities;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity  //from these annotation spring understands that these entity should map with table in database
@Table(name="users") //we use these annotation to specify string that these class should map with these table in database, these annotation we have to use mandatory when entity name in application & table name in database which we want to map are different
public class User {

	@Id //to specify string that these column as primary key for these entity which it maps to the table
	@GeneratedValue(strategy = GenerationType.IDENTITY) //these makes auto increment of ID col for each new entry of record.
	private long id;
	
	private String username;
	private String password;
	private String designation;
	
	//Getters and setters, these methods helps to retrieve the class object values, and set these class type objects.
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getDesignation() {
		return designation;
	}
	public void setDesignation(String designation) {
		this.designation = designation;
	}
	
	
	//when we print the User class object, then automatically these method will be called to print user object info in order format
	@Override
	public String toString() {
		return "User [id=" + id + ", username=" + username + ", password=" + password + ", designation=" + designation
				+ "]";
	}
	
	
	
	
}
