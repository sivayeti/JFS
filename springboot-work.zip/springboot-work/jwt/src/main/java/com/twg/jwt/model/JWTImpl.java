package com.twg.jwt.model;

import java.util.Date;

import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.security.Keys;

public class JWTImpl {

	//String secret = "TwgJwtClasses123"; //every server will have the secret code

	String secret = secret = "TeluguWebGuruJSONWebTokenClasses1234567890";
	//HMACSHA algorithm suggests us to use ‘ secret code = “TwgJwtClasses123”’ should be more than 256 bytes.

	//Lets take the secret code as ‘ secret = “TeluguWebGuruJSON WebTokenClasses1234567890” ‘

	
	
	
	
	
	//generate token - method for generating the token on Users info on users first request/login
	public String generateToken(UserLogin user)
	{
		//generate token using user information and token information
		
		//we have added 3 dependencies impl,api,jackson
		//now we have to know about the class 'Jwts' which is used to generate the token
		return Jwts
		 .builder()  //By using the Jwts.builder() method we can build the token and we have to build subject,issued at(iat),expired at,e.t.c with these .builder() after building then we will generate token.
		 .subject(user.getUsername())
		 .issuer("SivaYeti")
		 .issuedAt(new Date(System.currentTimeMillis())) //we have to give the date in milli-seconds
		 .expiration(new Date(System.currentTimeMillis()+60000))  //we have set the validity time for these token as half an hour from its issuer time.
		                                   //60000 milliseconds equal to 1 minute, so we are providing the validity for generated token for upto 1 minute from its issuer time.
		 
		//as of now what we are created is , subject,name,iat  which is payload, now we have to add signature for it.
		 .signWith(Keys.hmacShaKeyFor(secret.getBytes())) //we have taken that secret code as string, but here it has to passed as key format instead of string format. //So by using Keys.hmacShaKeyFor() we will convert the String in to Key format, and these method hmacShaKeyFr() accepts input in bytes format.
                        //so first we have to convert the Secret code from string to byte array using the .getBytes() method, after these convert the Secret_code_bytes_format into Keys format by using 'Keys.hmacShaKeyFor(secret.getBytes())' method. {string -> bytes -> key) //because signWith() method accepts the secret code argument in Key format
		 //In these way with .signWith() method signature will be created 
         //At last , whatever we configure payload,signature, and to build token on these , we have to use .compact() method, and return the string token.
         .compact(); //these compact() method will convert the generated token until now into String format.

          // return null;
		
		//from where we will call these generatedToken() method, at there these generated token will be returned.
	}
	
	
	
	
	
	
	
	
	
	
	
	//validate token - method for validating the token , which was sent by user from their next request.
	
	//Successfully now we generated the token, now lets perform validation which is for, after server generating the token and returns to client, now when client sends these token to server for next request, then server should validate these token to identify the particular client existed or not.
	//validation means,that token is true or false has to say.
public boolean isValidToken(String token)
{
	//to check the token validation we will use the same class 'Jwts' which we will use for token generation.
	/*
	Jwts
	.parser() //using the .parser() method we will parse the token //using the methods inside the .parser() we will validate the token. //now here we have to tell these is our 'token' & ' these is our 'secret key' and  using the secret key ,decrypt the token and then compare the signature or not
	.verifyWith(Keys.hmacShaKeyFor(secret.getBytes())) //here we say about our secret key
	.build() //lets build until now
	.parseSignedClaims(token); //here we said that these is our token
	*/
	//after decrypting the token with secret key, then after everything is matched or correct then there is no exception raised in these method, if anything is not matched or correct then exception raises, so enclose these statement with in {try-catch} block.

	try {
		Jwts.parser().verifyWith(Keys.hmacShaKeyFor(secret.getBytes())).build().parseSignedClaims(token);
	//if any exception or error not came with these line then token is correct enough
		return true;
	} catch (Exception e) {
		// TODO: handle exception
		//if any error is there with in try block then we will reach with in the catch block
		return false;
	} 
}
	

	
}
