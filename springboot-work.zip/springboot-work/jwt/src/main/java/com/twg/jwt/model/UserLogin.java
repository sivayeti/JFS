package com.twg.jwt.model;

public class UserLogin {

	//when user login , user only gives username, and password., for these if we used User class in entities it has 4 fields, (id,username,password,designation), to avoid these and to accept only username,passsword, we develped another class in model , which has fields username,passwords, which ensures better login action.
	
	String username;
	String password;
	
	
	//getters & setters
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
	
	
	//parameterized constructor
	public UserLogin(String username, String password) {
		super();
		this.username = username;
		this.password = password;
	}
	
	//empty constructor
	public UserLogin()
	{
		
	}
	
	//toString() method, when we print the 'UserLogin' class then automatically these method will be called.
	@Override
	public String toString() {
		return "UserLogin [username=" + username + ", password=" + password + "]";
	}
	
	
	
	
}
