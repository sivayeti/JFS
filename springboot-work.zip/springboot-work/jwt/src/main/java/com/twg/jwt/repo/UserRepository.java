package com.twg.jwt.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.twg.jwt.entities.User;

public interface UserRepository extends JpaRepository<User, Long> {

	//our interface UserRepository is alread a sub class of JPA Repository, these JPA repository provides all basic crud operations based on ID can be prepared on users table in database, when User class is passed as argument which is mapped to users table 

	//for customized queries we have to define here by using @Query annotation , JPA will prepare it

	public User findByUsername(String username); //simple customized queries, we can define here, JPA can prepares that method, but complex queries we have to specify the query which we want to perform on mapped table has to specify with @Query annotation
}
