package com.twg.jwt.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.twg.jwt.entities.User;
import com.twg.jwt.repo.UserRepository;

@Service
public class UserServiceImpl implements UserService {

	@Autowired
	private UserRepository userRepository; //from service layer , we will call the crud operations to perform on users table, so to call the methods in UserRepository Interface from UserServiceImpl, UserServiceImpl should have the UserRepository object, by using these object only we can acces the UserRepository methods, but we should not create UserRepository object here directy, we have to define the object here, but that object should be created outside ,and injected to defined object variable 'userRepository' during runtime, to avoid high coupling.//to achieve these we use @Autowired annotation //these activity can be handled by spring container
	
	
	@Override
	public User saveUser(User user) {
		// TODO Auto-generated method stub
		return userRepository.save(user);
	}

	@Override
	public User updateUser(User user) {
		// TODO Auto-generated method stub
		return userRepository.save(user);  //for both insertion & updation both we use the same method .save(object), and how it will works is, when we pass the object info without id, then save() performs insertion by creating auto-incremnet ID to it. If we pass the user object with Id, then .save() method verifies that these ID is existed in table, if it finds the existed ID record, then .save() performs update on the existed values with its current values on the passed ID record
	}

	@Override
	public void deleteUser(User user) {
		// TODO Auto-generated method stub
        userRepository.delete(user);
	}

	@Override
	public User findById(long id) {
		// TODO Auto-generated method stub
		return userRepository.findById(id).get(); //usually findByid() method returnd the record in "Object" format, but we want to retrieve in User class object format for that just add .get() at last.
	}

	@Override
	public List<User> findAll() {
		// TODO Auto-generated method stub
		return userRepository.findAll();
	}

	@Override
	public User findByUsername(String username) {
		// TODO Auto-generated method stub
		return userRepository.findByUsername(username);
	}

}
