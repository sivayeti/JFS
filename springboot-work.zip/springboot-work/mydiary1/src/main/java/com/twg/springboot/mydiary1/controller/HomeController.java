package com.twg.springboot.mydiary1.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.twg.springboot.mydiary1.entities.Entry;
import com.twg.springboot.mydiary1.entities.User;
import com.twg.springboot.mydiary1.service.EntryService;
import com.twg.springboot.mydiary1.service.UserService;

import jakarta.servlet.http.HttpSession;

@Controller  //since we are using .jsp files , we have to use @Controller instead of @RestController
public class HomeController {

		
	@Autowired
	private UserService userService;
	
	@Autowired
	private EntryService entryService;
	
	@Autowired //so HttpSession class, object is created by spring, and assign that objcet to here, where the HttpsSession class is used as property
	HttpSession session;
	
	
	
	
	//controller calls business or service methods, business layer calls dao layer methods

	public UserService getUserService() {
		return userService;
	}

	public void setUserService(UserService userService) {
		this.userService = userService;
	}

	public EntryService getEntryService() {
		return entryService;
	}

	public void setEntryService(EntryService entryService) {
		this.entryService = entryService;
	}

	
	//@RequestMapping("login") //change here @RequestMapping to appropriate @GET,@POST mappings
	@GetMapping("login")
	public String loginpage()
	{
		String model = new String("loginpage");
		
		
		
		return model;
	}
	
	@GetMapping("register")
	public String registrationpage()
	{
		String model = new String("registrationpage");
		
		
		
		return model;
	}
	
	
	//@GetMapping("saveuser")  //the above /register url accepts the both "get" & "post"
	@PostMapping(value="saveuser") //these .POST specifies that below method only serves for POST request
	public String saveuser(@ModelAttribute("user") User user)
	{
		//code to save the user details in the database
		
		String model = new String("registersuccess");
		
		userService.saveUser(user);
		
		
		return model;
	}
	
	
	//we will create a method, when a user entered his credentials in login form and click on  "login" button" , then those credentials should have to verify within users table in database, for that ,we have to map the login form action url to url on these methd
	/*
	@GetMapping(value="/authenticate", method=RequestMethod.POST)
	public String authenticateuser(@ModelAttribute("user") User user) //user object has "username","passwrd" entered by user in login form, now we have to check these credentials are presnet in users table
	{
		String model = new String("loginpage");
		//first we have to retrieve that for particular user entered username what password is there in users table in database,
		//then we have to verify that user entered password & retrieved password for that username are same or not if same means then user can authenticate, or navigate to other page, if not same then user can't authentcate
		
		String username = user.getUsername();
		User user1 = userService.findByUsername(username);
		
		//user object which is created based on the user entered credentials in login form
		//user1 object which is created based on the user row which we retrieved from the table based on the user entered username
		if(user1!=null && user.getPassword().equals(user1.getPassword()) ) 
		{
			model.setViewName("userhomepage");//if passwords match for user then user should navigate to "userhome page", if passwords not match user still in login page which we set the view for our model in start of method
			//model.addAttribute("user",user1.getUsername()); //from controller to view, controller can send the data to view by using addAttribute() of model
			             //key-name{about value},value
						 //key{name of value},user1.getUsername();
			model.addAttribute("user",user1); //key-name,,user1{object} which has username,password
		
			
			//when user is login successfully at that time what we have to do is: we have to add the each value, of user object
			session.setAttribute("user",user1); //user1 object which is retrieved from database , now it is stored in session variable "user", so we can use these session, whenever, wherever we want  the user info.
			
			
			
			List <Entry> entries = null;
			
			try {
				entries = entryService.findByUserid(user1.getId());
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			
			model.addAttribute("entrieslist",entries);
		}
		
		return model;
	} */
	@PostMapping(value="/authenticate")
	public String authenticateuser(@ModelAttribute("user") User user, Model model) //user object has "username","passwrd" entered by user in login form, now we have to check these credentials are presnet in users table
	{
		//String model = new String("loginpage");
		String viewname = new String("loginpage");
		
		String username = user.getUsername();
		User user1 = userService.findByUsername(username);
		
		
		if(user1!=null && user.getPassword().equals(user1.getPassword()) ) 
		{
			//model.setViewName("userhomepage");//if passwords match for user then user should navigate to "userhome page", if passwords not match user still in login page which we set the view for our model in start of method
			viewname = "userhomepage";
						
			//model.addAttribute("user",user1);
			model.addAttribute("user",user1);
			
			session.setAttribute("user",user1); //user1 object which is retrieved from database , now it is stored in session variable "user", so we can use these session, whenever, wherever we want  the user info.
			
			
			
			List<Entry> entries = null;
			
			try {
				entries = entryService.findByUserid(user1.getId());
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			
			model.addAttribute("entrieslist",entries);
		}
		
		//return model;
		return viewname;
	}
	
	
	//we have to prepare a method to view the particular user entries
	
	@GetMapping("addentry")
	public String addentry()
	{
		//when user clicks on these link/button then user should navigate to a page where all the inputs should displayed for Diary
		//String model = new String("addentryform");
		String viewname = new String("addentryform");
		
		User user1 = (User) session.getAttribute("user");
		//if user enter his credentials and reached to these page user variable has object value
		//if user reached to these page without using credential, and used url to reach it user object has null value
		
		if(user1==null) {
		//	model.setViewName("loginpage");
			viewname = "loginpage";
		}
		
		//return model;
		return viewname;
		
	}
	
	
	
	//the above method is for entry the values
	//The below method is for save the entries 
	//@GetMapping(value="saveentry" , method=RequestMethod.POST)
	@PostMapping(value="saveentry")
	public String saveentry(@ModelAttribute("entry") Entry entry, Model model)
	{
		//String model = new String("userhomepage");
		String viewname = "userhomepage";
		
		entryService.saveEntry(entry);
		
		User user1 = (User) session.getAttribute("user"); //In start using session variable user we store the user credentials you are currently done login successful, so even after login application forgots user credentials whenever it navigate to new url's, it can retrieve the users info from session variable
		
		
		List <Entry> entries = null;
		
		try {
			//entries = entryService.findByUserid(user1.getId());
			entries = entryService.findByUserid(user1.getId());
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		model.addAttribute("entrieslist",entries);
		
		//return model;
		return viewname;
	}
	
	
	
	@GetMapping("viewentry")
	public String viewentry(@RequestParam("id") long id, Model model) //if controller recieves object or {key,object} it should use @ModelAttribute(), if controller recieves variable which holds value, then we have to use @RequestParam
	{
		//String model = new String("displayentry");
		String viewname = "displayentry";
		
		Entry entry = entryService.findById(id);
		
		model.addAttribute("entry",entry);
		return viewname;
	}
	
	
	
	@GetMapping("userhomepage")
	public String userhomepage(Model model)
	{
		//String model = new String("userhomepage");
		String viewname = "userhomepage";
		
		
		User user1 = (User) session.getAttribute("user");
		
        List <Entry> entries = null;
		
		try {
			//entries = entryService.findByUserid(user1.getId());
			entries = entryService.findByUserid(user1.getId());
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		model.addAttribute("entrieslist",entries);
		
		return viewname;
	}
	
	
	
	@GetMapping("updateentry")
	public String updateentry(@RequestParam("id") long id, Model model) //if controller recieves object or {key,object} it should use @ModelAttribute(), if controller recieves variable which holds value, then we have to use @RequestParam
	{
		//String model = new String("displayupdateentry");
		String viewname = "displayupdateentry";
		
		Entry entry = entryService.findById(id);
		
		model.addAttribute("entry",entry);
		
		//here we can implement security functionality
		User user1 = (User) session.getAttribute("user");
		//if user enter his credentials and reached to these page user variable has object value
		//if user reached to these page without using credential, and used url to reach it user object has null value
		
		if(user1==null) {
			//model.setViewName("loginpage");
			viewname = "loginpage";
		}
		return viewname;
	}
	
	
	//@GetMapping(value="processentryupdate" , method=RequestMethod.POST)
	@PostMapping(value="processentryupdate")
	public String processentryuppdate(@ModelAttribute("entry") Entry entry, Model model)
	{
		//String model = new String("userhomepage");
		String viewname = "userhomepage";
		
		entryService.updateEntry(entry);
		User user1 = (User) session.getAttribute("user"); //In start using session variable user we store the user credentials you are currently done login successful, so even after login application forgots user credentials whenever it navigate to new url's, it can retrieve the users info from session variable
		
		
		List <Entry> entries = null;
		
		try {
			//entries = entryService.findByUserid(user1.getId());
			entries = entryService.findByUserid(user1.getId());
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		model.addAttribute("entrieslist",entries);
		return viewname;
	}
	
	
	
	@GetMapping("deleteentry")
	public String deleteentry(@RequestParam("id") long id, Model model)
	{
		//String model = new String("userhomepage");
		String viewname = "userhomepage";
		
		Entry entry = entryService.findById(id);
		//entryService.delete(entry);
		
		User user1 = (User) session.getAttribute("user"); //In start using session variable user we store the user credentials you are currently done login successful, so even after login application forgots user credentials whenever it navigate to new url's, it can retrieve the users info from session variable
		
		
		if(user1==null)
		{
			//model.setViewName("loginpage");
			viewname = "loginpage";
		}
		else
		{
			entryService.deleteEntry(entry);
		}
		List <Entry> entries = null;
		
		try {
			//entries = entryService.findByUserid(user1.getId());
			entries = entryService.findByUserid(user1.getId());
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		model.addAttribute("entrieslist",entries);
		return viewname;
	}
	  
	
	
	
	
	@GetMapping("signout")
	public String signout()
	{
		String model = new String("loginpage");
		
		session.invalidate(); //	user info in session variable should delete, then only session variable cqn store the respective users info
		return model;
	}
}
