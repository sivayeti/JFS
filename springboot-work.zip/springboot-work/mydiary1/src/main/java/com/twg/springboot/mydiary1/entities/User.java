package com.twg.springboot.mydiary1.entities;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity //to specify spring that these class should map with table in database
@Table(name = "users")  //to specify spring that these entity should match with users table in database. we have to use these annotation only when table name and entity names are different
public class User {

	@Id //These specifies the spring that these column is unique primary key
	@GeneratedValue(strategy =  GenerationType.IDENTITY) //These is for auto incrementation
	private long id;
	private String username;
	private String password;
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
	
}
