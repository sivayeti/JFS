package com.twg.springboot.mydiary1.service;


import java.util.List;

import com.twg.springboot.mydiary1.entities.Entry;

public interface EntryService {

	public Entry saveEntry(Entry entry);
	public Entry updateEntry(Entry entry);
	public void deleteEntry(Entry entry);
	public Entry findById(Long id);
	public List<Entry> findAll();
	
	public List<Entry> findByUserid(long id);
}
