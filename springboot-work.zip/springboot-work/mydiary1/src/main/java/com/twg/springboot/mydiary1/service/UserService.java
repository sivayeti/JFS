package com.twg.springboot.mydiary1.service;

import java.util.List;

import com.twg.springboot.mydiary1.entities.User;

public interface UserService {

	public User saveUser(User user);
	public User updateUser(User user);
	public void deleteUser(User user);
	public User findById(Long id);
	public List<User> findAll();
	public User findByUsername(String username);
}
