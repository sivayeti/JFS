<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<!-- by using the above tag we can use the jstl in jsp -->
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>

<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>MyDiary App Homepage</title>
<link rel="stylesheet" href= "<c:url value="/css/style.css"/>">
</head>
<body>  

	<div class = "header">
	<!-- For small book,& MyDiaryApp header I am making two divs in main div header -->
	
	<div class="first">
		<img src="<c:url value="/images/diary.jpg"/> " width="60" height="60">
	</div>
	
	<div class="second">MyDiaryApp</div>
		
	</div>
	<!--  To make two divisions should come in same line we have to use "float" property in css file-->
	
	<br/>
	<br/>
	<hr/>
	
	<h1>Welcome <span style="color:SteelBlue">${user.username}</span></h1>
		<a href="./signout" style="color:red;float:right">Signout</a>
	<div class="bodypart">
		
		<div class="bodypart1">
		<!--  
	<img src="/mydiary/resources/images/diary.jpg">--> <!-- if we give the project name directly here, if we want to change the project name, then we have to odify the old project name to new project name inside the each image tag, instead of that what we have to do is, during run time, the project should come and place before the /resources -->
	<!-- before resources our project name should came there durin run time,for that we use jstl technology -->


	<!-- In jstl tag lib , prefix=c, i.e wherever 'c' is there at that i am using jstl technology -->
		<img src="<c:url value="/images/diary.jpg"/> "> <!-- here these jstl syntax makes, to add project name before /resources during run time -->
		</div>
		
		
		<div class="bodypart2">
		<h1>UPDATE ENTRY</h1><br/><br/><br/>
		<form action="./processentryupdate" method="POST">
		
		<label>Date</label> <input type="date" name="entrydate" class="formcontrol" value="<fmt:formatDate value="${entry.entrydate}" pattern="yyyy-MM-dd"/>"  readonly>
		<br/><br/>
		
		<label>Description</label>
		<textarea rows="10" cols="30" name=description>${entry.description}</textarea>
		<input type="hidden" name="userid" value="${entry.userid}">
		<input type="hidden" name="id" value="${entry.id}">
		
		<br/><br/><br/>
		<button type="submit" >UPDATE ENTRY</button>
		</form>
		<br/><br/>
		
		
		
		</div>
	</div>
	


</body>
</html>