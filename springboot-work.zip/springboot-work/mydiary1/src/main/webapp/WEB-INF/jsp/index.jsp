<html>
	<head>
		<title>MyDiary Homepage</title>
		<body>
			Hello....
			Hi these is siva
			</body>
		</head>
	</html>