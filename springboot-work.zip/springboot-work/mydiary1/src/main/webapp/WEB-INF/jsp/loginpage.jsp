<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<!-- by using the above tag we can use the jstl in jsp -->
<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>MyDiary App Homepage</title>
<link rel="stylesheet" href= "<c:url value="/css/style.css"/>">
</head>
<body>

	<div class = "header">
	<!-- For small book,& MyDiaryApp header I am making two divs in main div header -->
	
	<div class="first">
		<img src="<c:url value="/images/diary.jpg"/> " width="60" height="60">
	</div>
	
	<div class="second">MyDiaryApp</div>
		
	</div>
	<!--  To make two divisions should come in same line we have to use "float" property in css file-->
	
	<br/>
	<br/>
	<hr/>
	
	
	<div class="bodypart">
		
		<div class="bodypart1">
		<!--  
	<img src="/mydiary/resources/images/diary.jpg">--> <!-- if we give the project name directly here, if we want to change the project name, then we have to odify the old project name to new project name inside the each image tag, instead of that what we have to do is, during run time, the project should come and place before the /resources -->
	<!-- before resources our project name should came there durin run time,for that we use jstl technology -->


	<!-- In jstl tag lib , prefix=c, i.e wherever 'c' is there at that i am using jstl technology -->
		<img src="<c:url value="/images/diary.jpg"/> "> <!-- here these jstl syntax makes, to add project name before /resources during run time -->
		</div>
		
		
		<div class="bodypart2">
		<h1>Login Here</h1><br/><br/><br/>
		<form action="./authenticate" method="POST">
		<label>username</label> <input type="text" name="username" class="formcontrol"><br/><br/>
		<label>password</label> <input type="password" name="password" class="formcontrol"><br/><br/><br/>
		<button type="submit" >LOGIN</button>
		</form>
		<br/><br/>
		
		<!--
		New User? <a href ="http://localhost:8080/springmvc/register">Register</a>here -->
		New User? <a href ="./register">Register</a>here 
		
		</div>
	</div>
	


</body>
</html>