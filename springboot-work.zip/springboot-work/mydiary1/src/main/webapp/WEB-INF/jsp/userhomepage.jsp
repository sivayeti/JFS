<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<!-- by using the above tag we can use the jstl in jsp -->

<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>User Home Page</title>
<!--  
<link rel="stylesheet" href= "<c:url value="/resources/styles/style.css"/>"> -->
<link rel="stylesheet" href="<c:url value="/css/style.css"/>">

</head>
<body>

	<div class = "header">
	<!-- For small book,& MyDiaryApp header I am making two divs in main div header -->
	
	<div class="first">
		<img src="<c:url value="/images/diary.jpg"/>" width="60" height="60">
	</div>
	
	<div class="second">MyDiaryApp</div>
		
	</div>
	<!--  To make two divisions should come in same line we have to use "float" property in css file-->
	
	<br/>
	<br/>
	<hr/>
	
	<br/><br/>
    

	<!--  
	<h1>Welcome to user home page</h1> -->
	
	<!--  
	<h1>Welcome ${user}</h1> --><!-- JSP expression language -->
	<div class="userhome">
	<!--  
	<h1>Welcome ${user.id}</h1>
	<h1>Welcome ${user.username}</h1>
	
	<h1>welcome ${user.password}</h1> -->
	
	welcome <span style="color:SteelBlue">${user.username}</span>
		<a href="./signout" style="color:red;float:right">Signout</a>
	<br/><br/><br/><br/>
	
	<span class="heading">List of Past Entries</span>
	
	
	<a href = "./addentry"><button type="button" class="addbtn">Add Entry</button></a>
	
	
	<br/><br/><br/><br/>
	
	
	<table border="1">
	<tr>
	<th>Date</th>
	<th colspan="3">Actions</th>
	</tr>
	
	<c:if test="${empty entrieslist}">
<tr>
  <td style="font-size:20px;color:green;text-align:center" colspan="4">
    User has not added any Diary entries till now.
  </td>
</tr>
</c:if>


	<c:forEach items="${entrieslist}" var="e">
		<tr>
		<td>
		<fmt:formatDate value="${e.entrydate}" pattern="dd/MM/yyyy" />
		
		</td>
		<td><a href="./viewentry?id=${e.id}">View</a></td>
		<td><a href="./updateentry?id=${e.id}">Update</a></td>
		<td><a href="./deleteentry?id=${e.id}">Delete</a></td>
		
		</tr>
	</c:forEach>
	</table>
	
	
	</div>
</body>
</html>