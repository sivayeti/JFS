package com.twg.springboot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Mydiary1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
