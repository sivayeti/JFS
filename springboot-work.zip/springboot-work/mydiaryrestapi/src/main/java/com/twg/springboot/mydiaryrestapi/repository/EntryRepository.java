package com.twg.springboot.mydiaryrestapi.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.twg.springboot.mydiaryrestapi.entities.Entry;

public interface EntryRepository extends JpaRepository<Entry, Long> {

	//@Query(value = "select * from entries where userid=:id", nativeQuery = true)
	public List<Entry> findByUserid(long id);  //for these normal queries we have to specify by findBycolName(id) , spring automatically prepares query, if any customized queries then we have to use "@Query"
}
